## RCarb 0.1.3 (Release date: 2019-02-11)

* Add README.md
* Modify output graphics and add more information

## RCarb 0.1.2 (Release date: 2018-12-02)

* Update internal references
* Modify example in write_InputTemplate() to comply with CRAN requests

## RCarb 0.1.1 (Release date: 2018-11-20)

* Internal changes only to account for CRAN comments on inital submission.

## RCarb 0.1.0 (Release date: 2018-11-12)

* Initial version
