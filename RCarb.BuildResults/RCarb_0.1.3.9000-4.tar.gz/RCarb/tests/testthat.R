library(testthat)
library(RCarb)

test_check("RCarb")